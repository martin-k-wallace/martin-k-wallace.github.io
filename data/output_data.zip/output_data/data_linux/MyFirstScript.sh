# !/bin/bash
# This script answers the question: What country had the highest "Infant_mortality" in 2012?
# usage: script.sh
grep 2012 OECD_Countries_Full.txt | grep Infant_mortality | sort -k6 | tail -n 1 | cut -f1,6 > CountryWithHighestMortality.txt
cat CountryWithHighestMortality.txt