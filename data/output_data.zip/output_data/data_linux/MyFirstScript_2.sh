# !/bin/bash
# This script answers the question: What country had the highest "Infant_mortality" in 2012?
# usage: script.sh $input

input=$1

grep 2012 $input | grep Infant_mortality | sort -k6 | tail -n 1 | cut -f1,6 > CountryWithHighestMortality_3.txt
cat CountryWithHighestMortality_3.txt