# !/bin/bash
# This script answers the question: What country had the highest "$1" in $3?
# usage: script.sh $1 $2 $3

grep $1 $2 | grep $3 | sort -k6 | tail -n 1 | cut -f1,6 > CountryWithHighestMortality_3.txt
cat CountryWithHighestMortality_3.txt